import React from "react";
import Tarjetas from "./tarjetas";

let habitaciones =[
  {
    nombre:"Single Room",
    description: "From $99",
    imagen:"https://www.w3schools.com/w3images/room_single.jpg"

  },
  {
    nombre:"Double Room",
    description: "From $149",
    imagen:"https://www.w3schools.com/w3images/room_double.jpg"

  },
  {
    nombre:"Delux Room",
    description: "From $199",
    imagen:"https://www.w3schools.com/w3images/room_deluxe.jpg"
  }
]

function Contenedor(){
  return(
    <div className="w3-row-padding">
            {
                habitaciones.map((info)=>( 
                    <Tarjetas imagen={info.imagen} description={info.description} nombre={info.nombre} /> 
                ))
            }
        </div>
  )
}



export default Contenedor;
